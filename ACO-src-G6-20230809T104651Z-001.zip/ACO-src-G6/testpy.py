import numpy as np

n = 10
m = 10
a = [i for i in range(n)]
b = {i:0 for i in range(n)}

iter = 0
while m>0:
    if iter >= len(a):
        np.random.shuffle(a)
        iter = 0
        print(a, iter)
    num_ants = np.random.randint(0,m + 1)
    b[a[iter]] += num_ants
    m -= num_ants
    iter += 1
    print(num_ants, m, b)
