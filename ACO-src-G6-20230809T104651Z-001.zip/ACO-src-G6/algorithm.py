import random
import time
import os
import psutil
import math
from copy import deepcopy
##
from sgraph import SGraph, GBSample
from optheap import OptHeap
# from multithread import MultipleThreading

def buildSeedSet( sgraph, threshold_T, seedFile, outFile, chartFile, samplingModel = "IC", numThread = 1):	## threshold T
	sg = sgraph
	## here: U<-V line 1 (change solution to U<-C_i)	
	k = sg.numGroupNode
	start = time.time()	
	print("Generate GBS sample...")
	GBS = GBSample(deepcopy(sg.graphNode), deepcopy(sg.graphGroup))
	RR = GBS.generateSample_multithread(model = samplingModel, numThread = numThread, reset = True)
	# RR = {}
	totalSample = GBS.totalSample
	# GBS = GBSample(deepcopy(sg.graphNode), deepcopy(sg.graphGroup))
	# for groupID in sg.graphGroup.keys():
	# 	# groupID, require, model = "IC", numThread = 1, reset = True
	# 	Ni = Ni_sample(len(sg.graphGroup[groupID]["nodeList"]), len(sg.graphNode))
	# 	print(f"Group [{groupID}] has require: {Ni} samples.")
	# 	RR[groupID] = GBSample(deepcopy(sg.graphNode), deepcopy(sg.graphGroup)).generateSample_multithread(groupID = groupID, require = Ni, model = samplingModel, numThread = numThread, reset = True)
	# 	totalSample += Ni
	stop = time.time()
	print(f"Done generate in [{numThread}] thread: total <{totalSample}> samples.")
	oFile = open(outFile,"a")
	oFile.write(f"\nDone generate in [{numThread}] thread: total <{totalSample}> samples.")
	oFile.write(f"\nGenerate time: {stop - start :.2f}s")	## did not close yet
	##
	cFile = open(chartFile,"a")
	cFile.write(f"\n{numThread}\n{totalSample}\n{stop - start :.2f}")
	cFile.close()
	print("Find the first candidate solution S1")
	oFile.write("Find the first candidate solution S1")
	start = time.time()
	S = {groupID : set() for groupID in range(k)}
	C = {groupID : set() for groupID in range(k)}
	R = {groupID : set() for groupID in range(k)}
	U = set(sg.graphNode.keys())	## U = V = [nodeID for nodeID in sg.graphNode.keys()]
	for groupID in sg.graphGroup.keys():
		# U = set(sg.graphGroup[groupID]["nodeList"])
		EBi_Si = 0
		t_i = sg.graphGroup[groupID]["thresholdScore"]
		print(f"Find seed set of group C[{groupID}]: threshold t_i = {t_i}")
		oFile.write(f"\nFind seed set of group C[{groupID}]: threshold t_i = {t_i}")
		while EBi_Si < t_i and U:	## U not empty
			# sg, groupID, S, U, coverSample, EBi_S, RRi
			heap = buildHeap_line7(sg, groupID, S[groupID], U, R[groupID], EBi_Si, RR[groupID])
			if heap.isEmpty():
				break;
			heapNode = heap.pop()
			f, u, EBi_Si = heapNode
			print(f"Add node {u}\tEBi_Si[{groupID}]: {EBi_Si}")
			oFile.write(f"\nAdd node {u}\tEBi_Si[{groupID}]: {EBi_Si}")
			S[groupID].add(u)
			C[groupID].update(sg.graphNode[u]["groupID"])
			R[groupID].update(RR[groupID]["cover"][u])
			U.discard(u)
	S1 = set()
	C1 = set()
	R1 = R
	for i in range(k):
		S1.update(S[i])
		C1.update(C[i])
		# R1.update(R[i])
	## free S,C,R storage (?)
	oFile = open(outFile,"a")
	print(f"Discard seed node out of S1: threshold_T = {threshold_T}")
	oFile.write(f"\nDiscard seed node out of S1: threshold_T = {threshold_T}")
	U = set(S1)
	EB_S = estimate_total(sg, C1, R1, RR)
	print(f"EB_S: {EB_S}")
	# for i in range(k): ## wut the (?)
	while U:
		# heap = buildHeap_line15(sg, S1, R1, C1, RR)
		# heapNode = heap.pop()
		# u,EB_S_discard = heapNode[0],heapNode[-1]
		u, EB_S_discard = buildHeap_line15(sg, U, C1, R1, RR)
		if EB_S_discard >= threshold_T:
			print(f"Remove node {u}\tEB_S_discard: {EB_S_discard}")
			oFile.write(f"\nRemove node {u}\tEB_S_discard: {EB_S_discard}")
			S1.discard(u)
			EB_S = EB_S_discard
			groupIDList = sg.graphNode[u]["groupID"]
			C1.difference_update(groupIDList)
			for groupID in groupIDList:
				R1[groupID].difference_update(RR[groupID]["cover"][u])
		U.discard(u)
	start2 = time.time()
	stop = time.time()
	## choose the final seed set which touch min cost value
	total_S1 = {"benefit" : 0, "cost" : 0}
	# total_S2 = {"benefit" : 0, "cost" : 0}
	for u in S1:
		total_S1["cost"] += sg.graphNode[u]["cost"]
		total_S1["benefit"] += sg.graphNode[u]["benefit"]
	oFile.write(f"\nS_numSeed: {len(S1)}\nS_estimateInfluence: {EB_S :.2f}\nS_totalCost: {total_S1['cost']:.2f}\nS_totalBenefit: {total_S1['benefit']}\nS_calculateTime: {start2 - start:.2f}s")	
	cFile = open(chartFile,"a")
	cFile.write(f"\n{len(S1)}\n{EB_S:.4f}\n{total_S1['cost']:.2f}\n{total_S1['benefit']}\n{start2-start:.2f}")
	##
	print(f"S1 totalCost: {total_S1['cost'] :.2f}")	
	result = {sg.graphNodeLabel[seed] for seed in S1}
	oFile.close()
	cFile.close()
	## write down to seed file
	# with open(seedFile,"w") as sFile:	
	sFile = open(seedFile,"w")
	sFile.writelines("%s " %seed for seed in result)
	sFile.close()
	##	
	return result

def Ni_sample(numGroupNode, numNode, epsilon = 0.1):
	## static parameters
	# epsilon = 0.1		## 1, 0.1, 0.01
	delta = 1/numNode
	return int((2 + 2/3 * epsilon) * numGroupNode * (1/pow(epsilon,2)) * math.log(1/delta))

def estimate_group(totalScore, num_coverSample, num_totalSample):
	return totalScore * num_coverSample / num_totalSample

## EB: estimate benefit all group
def estimate_total(sg, coverGroup, coverSample, RR):
	EB = 0
	for groupID in coverGroup:
		EB += estimate_group(sg.graphGroup[groupID]["groupTotalScore"], len(coverSample[groupID]), RR[groupID]["numSample"])
	return EB

def buildHeap_line7(sg, groupID, S, U, coverSample, EBi_S, RRi):
	## each group
	heap = OptHeap([0],[1])	## 1: decrease heap
	nodeList = U.difference(S)
	for v in nodeList:
		## suppose v in S
		S_v = S.union({v})
		## update cover sample
		if v in RRi["cover"]:
			R_v = coverSample.union(RRi["cover"][v])
		else:
			R_v = coverSample
		## estimate group Ci with S_v
		EBi_S_v = estimate_group(totalScore = sg.graphGroup[groupID]["groupTotalScore"], num_coverSample =  len(R_v), num_totalSample = RRi["numSample"])
		f = (EBi_S_v - EBi_S) / sg.graphNode[v]["cost"]
		heap.push((f, v, EBi_S_v))
	heap.heapify()
	return heap

def buildHeap_line15(sg, nodeList, coverGroup, coverSample, RR):
	heap = OptHeap([0],[1]) ## 1: decrease heap
	for v in nodeList:
		heap.push((sg.graphNode[v]["cost"],v))
	heap.heapify()
	maxCost, u = heap.pop()
	# suppose discard u out of nodeList
	S_discard = nodeList.difference({u})
	## update cover group: each node belong to only group that Ci can not intersection Cj
	groupIDList = sg.graphNode[u]["groupID"]
	C_discard = coverGroup.difference(groupIDList)
	## update cover sample 
	R_discard = coverSample
	for groupID in groupIDList:
		R_discard[groupID] = coverSample[groupID].difference(RR[groupID]["cover"][u])
	## estimate all group
	# EB_S = estimate_total(sg, C1, R1, RR)
	EB_S_discard = estimate_total(sg = sg, coverGroup = C_discard, coverSample = R_discard, RR = RR)
	return u, EB_S_discard

def buildHeap_line22(sg, groupID, S, coverGroup, coverSample, EBi_S, RR):
	heap = OptHeap([0],[1])
	# nodeList  = {nodeID if nodeID not in S for nodeID in sg.graphNode.keys()}.difference(S)
	nodeList = {nodeID for nodeID in sg.graphNode.keys()}.difference(S)
	for v in nodeList:
		## suppose v in S
		S_v = S.union({v})
		## update cover group
		C_v = coverGroup.union(sg.graphNode[v]["groupID"])
		## update cover sample
		R_v = coverSample.union(RR["cover"][v])
		## estimate all group 
		EBi_S_v = estimate_group(sg, groupID, R_v, RR)
		EB_S_v = estimate_total(sg, C_v, R_v, RR)
		f = (EB_S_v - EBi_S_v) / sg.graphNode[v]["cost"]
		heap.push((f, v, EBi_S_v, EB_S_v))
	heap.heapify()
	return heap