import sys
from copy import *
# import queue
import time
import math
import queue
import random
import threading

class SGraph:
	__graphName = None
	__numNode = __numEdge = __numGroupNode = None
	__graphNodeLabel = None
	__graphNode = __graphGroupNode = None
	## getter
	@property
	def graphName(self):
		return self.__graphName
	@property
	def numNode(self):
		return self.__numNode
	@property
	def numEdge(self):
		return self.__numEdge
	@property
	def numGroupNode(self):
		return self.__numGroupNode
	@property
	def graphNodeLabel(self):
		return self.__graphNodeLabel
	@property
	def graphNode(self):
		return deepcopy(self.__graphNode)
	@property
	def graphGroup(self):
		return deepcopy(self.__graphGroupNode)
	## constructor(s)
	def __init__(self, attsList = None):
		if not attsList:
			attsList = SGraph.sAttsList()
		self.__graphName = attsList["graphName"]
		self.__numNode = attsList["numNode"]
		self.__numEdge = attsList["numEdge"]
		self.__numGroupNode = attsList["numGroupNode"]
		self.__graphNodeLabel = attsList["graphNodeLabel"]
		self.__graphNode = attsList["graphNode"]
		self.__graphGroupNode = attsList["graphGroup"]
	## object instance initialize
	@classmethod
	def cInit(cls, attsList = None):
		sg = cls(attsList)
		return sg
	## default attributes list
	@staticmethod
	def sAttsList(graphName = None, numNode = 0, numEdge = 0, numGroupNode = 0, graphNodeLabel = [], graphNode = {}, graphGroup = {}):
		return {
			"graphName" : str(graphName),
			"numNode" : int(numNode),
			"numEdge" : int(numEdge),
			"numGroupNode" : int(numGroupNode),
			"graphNodeLabel" : tuple(graphNodeLabel),
			"graphNode" : graphNode,
			"graphGroup" : graphGroup
		}
	## create default graph node
	@staticmethod
	def sGraphNode(adjList = {}, benefit = 0, cost = 0, score = 0):
		return {
			"adjList" : adjList,
			"cost" : cost,
			"benefit" : benefit,
			"score" : score	
		}
	def nodeAtt(self, nodeID, att = "inDegree"):
		if nodeID in self.__graphNode:
			return self.__graphNode[nodeID][att]
		return None
	## create default graph group node
	@staticmethod
	def sGraphGroupNode(nodeList = set(), groupTotalScore = 0, thresholdScore = 0):
		return {
			"nodeList" : nodeList,
			"groupTotalScore" : groupTotalScore,
			"thresholdScore" : thresholdScore
		}
	## load graph dataset from file
	@staticmethod
	def sParseGraph(path, graphName = None, numThread = 1):
		print(f"Load graph input dataset...")
		lines = readFile_ParseLine(path,numThread)
		if not lines:
			print(lines)	## debugging: result flag
			return False
		try:
			## parse header line and graph nodes label
			# attsList = SGraph.sAttsList()
			# attsList["graphName"] = graphName
			# attsList["numNode"], attsList["numEdge"], attsList["numGroupNode"] = line[0]
			# attsList["graphNodeLabel"] = tuple(line[1])
			attsList = SGraph.sAttsList(graphName,*lines[0],lines[1])
			##
			# initial graph node list
			if len(lines) < 5 + int(attsList["numNode"]) + int(attsList["numGroupNode"]) + 1:
				print(f"Error: Unable to parse graph, file format does not contain enough lines.")
				return False
			attsList["graphNode"] = {nodeID:SGraph.sGraphNode() for nodeID in range(attsList["numNode"])}
			# parse cost and benefit line
			for nodeID in range(attsList["numNode"]):
				attsList["graphNode"][nodeID]["cost"] = float(lines[2][nodeID])
				attsList["graphNode"][nodeID]["benefit"] = float(lines[3][nodeID])
				attsList["graphNode"][nodeID]["score"] = float(lines[4][nodeID])
				attsList["graphNode"][nodeID]["groupID"] = set()
			point = 5	## start read from point line
			## muitlthread (?)
			## n lines for adjacency reverse list
			for nodeID in range(attsList["numNode"]):
				if len(lines[point+nodeID]) == 0 or not lines[point+nodeID][0].isnumeric():
					attsList["graphNode"][nodeID]["adjList"] = set()
				else:
					attsList["graphNode"][nodeID]["adjList"] = set(map(int,lines[point+nodeID]))
			# for nodeID in range(attsList["numNode"]):
			# 	for source in lines[point+i]:
			# 		attsList["graphNode"][nodeID]["adjList"][source] = {}
			# point += attsList["numNode"]
			# ## n lines for ajacency weight list
			# for nodeID in range(attsList["numNode"]):
			# 	for weight in lines[point+i]:
			# 		attsList["graphNode"][nodeID]["adjList"][source]["weight"] = weight
			# for nodeID in range(attsList["numNode"]):
			# 	for i in range(len(lines[point+nodeID])):
			# 		attsList["graphNode"][nodeID] source = lines[point+nodeID][i]
			## c lines for list of groups
			attsList["graphGroup"] = {groupID:SGraph.sGraphGroupNode() for groupID in range(attsList["numGroupNode"])}
			point = point + attsList["numNode"]
			for groupID in range(attsList["numGroupNode"]):
				if len(lines[point+groupID]) == 0 or not lines[point+groupID][0].isnumeric():
					attsList["graphGroup"][groupID]["nodeList"] = set()		## impossible
				else:
					attsList["graphGroup"][groupID]["nodeList"] = set(map(int,lines[point+groupID]))
				for nodeID in attsList["graphGroup"][groupID]["nodeList"]:
					attsList["graphGroup"][groupID]["groupTotalScore"] += attsList["graphNode"][nodeID]["score"]
					attsList["graphNode"][nodeID]["groupID"].add(groupID)	
			point = point + attsList["numGroupNode"]
			## parse cost and benefit line of each group
			for groupID in range(attsList["numGroupNode"]):
				attsList["graphGroup"][groupID]["thresholdScore"] = float(lines[point][groupID])
			# print(attsList)
		except:
			print("Error: Unable to parse graph, file format missing does not right.")
			return False
		else:
			print(f"Done parsing graph dataset.")
			return attsList
	## object instance initialize with graph dataset
	@classmethod
	def cReadFile_GraphFormatted(cls, path, graphName = None, numThread = 1):
		return cls.cInit(SGraph.sParseGraph(path, graphName, numThread))
	## re-init object with graph dataset
	def readFile_GraphFormatted(self, path, graphName = None, numThread = 1):
		self(SGraph.sParseGraph(path, graphName, numThread))
	## object print
	def print(self, detail = False):
		print(self)
		print(f"Graph name: {self.graphName}")
		print(f"Graph num node: {self.numNode}")
		print(f"Graph num edge: {self.numEdge}")
		print(f"Graph num group node: {self.numGroupNode}")		
		if detail:
			## for debugging
			print(f"Graph nodes label: {self.graphNodeLabel}")
			print(f"Graph nodes: {self.graphNode}")
			print(f"Graph group nodes: {self.graphGroup}")
	##############-Function-Using-For-Algorithm-##############
	## multithread (?)
	
def readFile_ParseLine(path, numThread = 1):
	def __parseLine(string):
		# string = string.strip()
		lines = string.split("\n");
		if not lines:
			return None
		for i in range(len(lines)):
			lines[i] = lines[i].strip()
			lines[i] = lines[i].split(" ")	## regex?
		return lines
	start = time.perf_counter()
	print(f"Reading file: {path}")
	try:
		## type of file: "r","rb"
		with open(path,"r") as file:
			## multithread (?)
			data = file.read()
			print(f"Read file in: {time.perf_counter() - start}")
		file.close()
	except IOError: 
		print("Error: File does not appear to exist.")
		return False
	else:
		lines = __parseLine(data)
		if not lines:
			print(f"Error: File does not contain any readable data.")
			return None
		print(f"Success reading file.")
		return lines
	return None


####################################################################################

class GBSample:
	threadList = {"mapping_thread": {}, "sampling_thread" : {}}
	lock_threading = None
	mappingQueue = None
	stopFlag = None
	RR = None
	Ni = None
	totalSample = None
	def __init__(self, graphNode, graphGroup, reset = True):
		self.graphNode = graphNode
		self.graphGroup = graphGroup
		if reset:
			self.reset()
	@classmethod
	def cInit(cls, graphNode, graphGroup, reset = True):
		gbs = cls(graphNode, graphNode, reset)
		return gbs
	def reset(self):
		self.mappingQueue = queue.Queue()
		self.RR = {}
		self.totalSample = 0
		##
		self.stopFlag = False
		self.threadList = []
	## threading
	def mapping_thread(self):
		while not (self.mappingQueue.empty() and self.stopFlag):
		# while not self.stopFlag:
			if self.mappingQueue.empty():
				# print("wait")
				time.sleep(1)
				continue
			groupID, sampleID = self.mappingQueue.get()
			# print(f"Group [{groupID}] mapping: {sampleID}")
			## 
			for nodeID in self.RR[groupID]["sample"][sampleID]:
				if nodeID not in self.RR[groupID]["cover"]:
					self.RR[groupID]["cover"][nodeID] = set()
				## add cover sample in to set of cover node u
				self.RR[groupID]["cover"][nodeID].add(sampleID)
	def get(self):
		# return { "sample" : deepcopy(self.sample), "cover" : deepcopy(self.cover)}
		return {groupID:{"numSample":self.RR[groupID]["numSample"] , "cover" : self.RR[groupID]["cover"]} for groupID in self.graphGroup.keys()}
	def print(self):
		print(f"Num sample : {len(self.sample)}")
		print(f"Num cover : {len(self.cover)}")
	def GroupBenefitSample_IC(self, groupID):
		Q = queue.Queue()
		R = []
		## random source node
		graphGroupNode = self.graphGroup[groupID]
		# rand_reach = graphGroupNode[random.randint(0,len(graphGroupNode)-1)];
		## or rand_source = arg max(score / total scorce) (?)
		maxF = 0
		rand_reach = None
		for v in graphGroupNode["nodeList"]:
			if self.graphNode[v]["score"] / graphGroupNode["groupTotalScore"] > maxF:
				maxF = self.graphNode[v]["score"]
				rand_reach = v
		if rand_reach == None:
			return None
		## reverse live edge (model IC)
		Q.put(rand_reach)
		R.append(rand_reach)
		while not Q.empty():
			v = Q.get()
			for u in self.graphNode[v]["adjList"]:
				if u not in R:
					rand_prob = random.random()
					if len(self.graphNode[v]["adjList"]) == 0:
						prob = 0.9999 								## here
					else:
						prob = 1/len(self.graphNode[v]["adjList"])
					if rand_prob <= prob:
						Q.put(u)
						R.append(u)
					break
		return R
	## threading
	def sampling_thread(self, require, groupID, model = "IC"):
		for i in range(require):
			if model == "IC":
				R = self.GroupBenefitSample_IC(groupID)
			if R:
				## lock for write
				self.lock_sample.acquire()
				sampleID = self.totalSample
				self.mappingQueue.put((groupID,sampleID))
				self.RR[groupID]["sample"][sampleID] = R
				self.totalSample += 1
				self.lock_sample.release()
				## unlocked
	def divideZ(self,n,t,z):
		if t == 0:
			return None
		if t == 1:
			z.append(n)
			return True
		z.append(n//t)
		self.divideZ(n-z[-1],t-1,z)
	# def generateSample_multithread2(self, model = "IC", numThread = 1, reset = True):
	# 	if not numThread or numThread <= 0:
	# 		numThread = 1
	# 	if reset:
	# 		self.reset()

	# 	requireSplit = []
	# 	self.divideZ(n = require, t = numThread, z = requireSplit)
	# 	## mapping thread
	# 	# self.threadList["mapping_thread"] = {"stopFlag" : False}
	# 	self.stopFlag = False
	# 	mappingThread = threading.Thread(target = self.mapping_thread, args = ())	## daemon = True
	# 	self.threadList["mapping_thread"]["thread"] = mappingThread
	# 	mappingThread.start()
	# 	## thread lock variable
	# 	self.lock_sample = threading.Lock()
	# 	## generate sample in multithread mode
	# 	for i in range(numThread):
	# 		samplingThread = threading.Thread(target = self.sampling_thread, args = (requireSplit[i], groupID), daemon = True)
	# 		self.threadList["sampling_thread"][i] = samplingThread
	# 		samplingThread.start()
	# 	## join all thread, wait for last sampling
	# 	for i in range(numThread):
	# 		self.threadList["sampling_thread"][i].join()
	# 	## call stop for mapping thread, wait for last mapping sample
	# 	self.stopFlag = True
	# 	mappingThread.join()
	# 	## check thread still alive
	# 	while self.threadList["mapping_thread"]["thread"].is_alive():
	# 		print("still alive")
	# 		time.sleep(1)
	# 	## count for num of sample has generated
	# 	self.lock_sample.acquire()
	# 	print(f"Generate: {len(self.sample)}")
	# 	self.lock_sample.release()
	# 	return self.get()
	def Ni_sample(self, numGroupNode, numNode, epsilon = 0.1):
		## static parameters
		# epsilon = 0.1		## 1, 0.1, 0.01
		delta = 1/numNode
		return int((2 + 2/3 * epsilon) * numGroupNode * (1/pow(epsilon,2)) * math.log(1/delta))
	def generateSample_multithread(self, model = "IC", numThread = 1, reset = True):
		if not numThread or numThread <= 0:
			numThread = 1
		if reset:
			self.reset()
		## init require number of sample
		# self.Ni = {}
		# for groupID in self.graphGroup.keys():
		# 	self.Ni[groupID] = int(self.Ni_sample(len(self.graphGroup[groupID]["nodeList"]), len(self.graphNode)))
		# 	self.totalSample += self.Ni[groupID]
		## mapping thread for mapping count new Rj sample into cover node list
		mappingThread = threading.Thread(target = self.mapping_thread, args = (), daemon = True)
		mappingThread.start()
		## sampling thread for sample require
		self.lock_sample = threading.Lock()
		for groupID in self.graphGroup.keys():
			Ni = int(self.Ni_sample(len(self.graphGroup[groupID]["nodeList"]), len(self.graphNode)))
			print(f"Group [{groupID}] has require: {Ni} samples.")
			self.RR[groupID] = {"sample" : {}, "numSample": Ni, "cover": {nodeID: set() for nodeID in self.graphGroup[groupID]["nodeList"]}}
			requireSplit = []
			self.divideZ(n = Ni, t = numThread, z = requireSplit)
			for i in range(numThread):
				samplingThread = threading.Thread(target = self.sampling_thread, args = (requireSplit[i], groupID), daemon = True)
				self.threadList.append(samplingThread)
				samplingThread.start()
			for i in range(numThread):
				self.threadList[i].join()
			self.lock_sample.acquire()
			print(f"Generate: {len(self.RR[groupID]['sample'])}")
			self.lock_sample.release()
			## empty thread list
			self.threadList = []
		## call stop for mapping thread
		self.stopFlag = True
		mappingThread.join()
		## 
		## check thread still alive
		# while self.threadList["mapping_thread"]["thread"].is_alive():
			# time.sleep(1)
		return self.get()
