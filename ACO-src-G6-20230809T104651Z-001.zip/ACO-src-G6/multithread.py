import threading
import time
import random

class MultipleThreading:
	threadList = None
	def __init__(self):
		self.threadList = {}
	def createThread(self,name,target,args = ()):
		self.threadList[name] = {
			"thread": threading.Thread(target = target, args = args),
			"time":	None,
			"memory": None,
		}
	def releaseThread(self,name):
		self.threadList.pop(name,None)
	def startThread(self,name):
		if name not in self.threadList:
			print(f"Thread name \"{name}\" doesn't exist.")
			return False
		thread = threadList[name]
		start = time.time()
		thread.start()
		end = time.time()
		thread["time"] = end-start
		return True
	def joinThread(self,name):
		if name not in self.threadList:
			print(f"Thread name \"{name}\" doesn't exist.")
			return False
		thread = threadList[name]
		thread.join()
		return True
	def startAllThread(self):
		if not self.threadList:
			print(f"No thread has found.")
			return False
		for thread in self.threadList.values():
			start = time.time()
			thread["thread"].start()
			end = time.time()
			thread["time"] = end-start
		return True
	def joinAllThread(self):
		if not self.threadList:
			print(f"No thread has found.")
			return False	
		for thread in self.threadList.values():
			thread["thread"].join()
		return True
	def getNumThread(self):
		return len(self.threadList)
	def printThreadAtts(self,name):
		if name not in self.threadList:
			return None
		thread = self.threadList[name]
		time, memory = thread["time"], thread["memory"]
		print(f"name: {name}\ttime:{time}\tmemory:{memory}")